package com.example.wlednothing

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews
import org.json.JSONArray
import org.json.JSONObject
import kotlin.concurrent.thread

class WledWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action != ACTION) return
        val prefs = context.getSharedPreferences("wled", Context.MODE_PRIVATE)
        val host = prefs.getString("host", "").orEmpty()
        val action = intent.getStringExtra("action") ?: return
        when (action) {
            "open" -> {
                if (host.isNotBlank()) {
                    val open = Intent(Intent.ACTION_VIEW, Uri.parse("http://$host")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(open)
                } else context.startActivity(Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            "app" -> context.startActivity(Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            else -> {
                if (host.isBlank()) {
                    context.startActivity(Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    return
                }
                thread {
                    try {
                        when (action) {
                            "power" -> {
                                val next = !prefs.getBoolean("on", true)
                                WledApi.send(host, JSONObject().put("on", next))
                                prefs.edit().putBoolean("on", next).apply()
                            }
                            "sync" -> {
                                val next = !prefs.getBoolean("sync", false)
                                WledApi.send(host, JSONObject().put("udpn", JSONObject().put("send", next).put("recv", next)))
                                prefs.edit().putBoolean("sync", next).apply()
                            }
                            "next" -> applyPreset(context, host, prefs, 1)
                            "dot" -> applyPreset(context, host, prefs, 1)
                        }
                        val manager = AppWidgetManager.getInstance(context)
                        val ids = manager.getAppWidgetIds(ComponentName(context, WledWidgetProvider::class.java))
                        ids.forEach { update(context, manager, it) }
                    } catch (_: Exception) { }
                }
            }
        }
    }

    companion object {
        const val ACTION = "com.example.wlednothing.WIDGET_ACTION"

        fun update(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val p = context.getSharedPreferences("wled", Context.MODE_PRIVATE)
            val views = RemoteViews(context.packageName, com.example.wlednothing.R.layout.wled_widget)
            val name = p.getString("presetName", "Rainbow") ?: "Rainbow"
            val index = p.getInt("presetIndex", 0)
            val count = p.getInt("presetCount", 0)
            val on = p.getBoolean("on", true)
            val sync = p.getBoolean("sync", false)
            val bri = p.getInt("bri", 190)
            views.setTextViewText(R.id.widgetPresetName, name)
            val dotCount = minOf(if (count > 0) count else 5, 8)
            val dots = (0 until dotCount).joinToString("  ") { if (it == index % dotCount) "●" else "·" }
            views.setTextViewText(R.id.widgetDotsText, dots)
            views.setProgressBar(R.id.widgetBrightness, 255, bri, false)
            views.setInt(R.id.widgetRoot, "setBackgroundColor", glowColor(p.getInt("glow", 0xFF292029.toInt()), on))
            views.setInt(R.id.widgetPower, "setBackgroundColor", if (on) 0xFFEEEEEE.toInt() else 0xFF363636.toInt())
            views.setTextColor(R.id.widgetPower, if (on) 0xFF111111.toInt() else 0xFFFFFFFF.toInt())
            views.setInt(R.id.widgetSync, "setBackgroundColor", if (sync) 0xFFEEEEEE.toInt() else 0xFF363636.toInt())
            views.setTextColor(R.id.widgetSync, if (sync) 0xFF111111.toInt() else 0xFFFFFFFF.toInt())
            setAction(context, views, R.id.widgetOpen, "open", widgetId)
            setAction(context, views, R.id.widgetSync, "sync", widgetId)
            setAction(context, views, R.id.widgetPower, "power", widgetId)
            setAction(context, views, R.id.widgetPresetName, "next", widgetId)
            setAction(context, views, R.id.widgetDots, "dot", widgetId)
            setAction(context, views, R.id.widgetBrightness, "app", widgetId)
            manager.updateAppWidget(widgetId, views)
        }

        private fun setAction(context: Context, views: RemoteViews, viewId: Int, action: String, id: Int) {
            val intent = Intent(context, WledWidgetProvider::class.java).setAction(ACTION).putExtra("action", action).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            val pending = PendingIntent.getBroadcast(context, id * 100 + action.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(viewId, pending)
        }

        private fun applyPreset(context: Context, host: String, prefs: android.content.SharedPreferences, delta: Int) {
            val list = try { WledApi.presets(host) } catch (_: Exception) { emptyList() }
            if (list.isEmpty()) return
            val currentId = prefs.getInt("presetId", 0)
            val current = list.indexOfFirst { it.id == currentId }.let { if (it < 0) 0 else it }
            val next = list[(current + delta + list.size) % list.size]
            WledApi.send(host, JSONObject().put("ps", next.id).put("on", true))
            prefs.edit().putInt("presetId", next.id).putInt("presetIndex", (current + delta + list.size) % list.size).putString("presetName", next.name).putBoolean("on", true).putInt("presetCount", list.size).apply()
        }

        private fun glowColor(color: Int, on: Boolean): Int = if (on) color else 0xFF101010.toInt()
    }
}
