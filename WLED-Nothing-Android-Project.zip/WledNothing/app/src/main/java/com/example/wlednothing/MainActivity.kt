package com.example.wlednothing

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import org.json.JSONObject
import kotlin.concurrent.thread
import kotlin.math.abs

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("wled", Context.MODE_PRIVATE) }
    private lateinit var hostInput: EditText
    private lateinit var status: TextView
    private lateinit var presetName: TextView
    private lateinit var dots: LinearLayout
    private lateinit var brightness: SeekBar
    private lateinit var card: LinearLayout
    private var presets: List<Preset> = emptyList()
    private var currentIndex = 0
    private var currentPresetId = 0
    private var isOn = true
    private var isSync = false
    private var brightnessValue = 190
    private var touchStartX = 0f
    private var touchStartY = 0f

    private val host: String get() = prefs.getString("host", "").orEmpty()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 16, 16)
        window.navigationBarColor = Color.rgb(16, 16, 16)
        window.decorView.systemUiVisibility = 0
        buildUi()
        hostInput.setText(host)
        refreshFromDevice()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(20))
            setBackgroundColor(Color.rgb(16, 16, 16))
        }
        val title = text("WLED", 28f, Color.WHITE, true)
        root.addView(title, matchWrap())
        root.addView(text("NOTHING-STYLE CONTROLLER", 10f, 0xFF929292.toInt(), true).apply { letterSpacing = .16f }, marginParams(-2, 8, 0, 20))

        val hostRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        hostInput = EditText(this).apply {
            hint = "IP-адрес, например 192.168.1.50"
            setSingleLine(true)
            textSize = 14f
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF777777.toInt())
            setPadding(dp(14), 0, dp(10), 0)
            background = rounded(0xFF252525.toInt(), 14)
            inputType = android.text.InputType.TYPE_CLASS_TEXT
        }
        hostRow.addView(hostInput, LinearLayout.LayoutParams(0, dp(48), 1f))
        val connect = button("Подключить") { saveHostAndConnect() }
        hostRow.addView(connect, marginParams(0, 0, 0, 0, 8, 0))
        root.addView(hostRow, matchWrap())
        status = text("Укажи IP-адрес своего WLED-контроллера", 12f, 0xFFAAAAAA.toInt())
        root.addView(status, marginParams(-2, 10, 0, 16))

        card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(12), dp(12))
            background = rounded(0xFF292029.toInt(), 24)
        }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        val nameLine = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        presetName = text("Rainbow", 16f, Color.WHITE, true)
        nameLine.addView(presetName, LinearLayout.LayoutParams(0, dp(28), 1f))
        dots = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL or Gravity.END }
        nameLine.addView(dots, LinearLayout.LayoutParams(-2, dp(28)))
        left.addView(nameLine, matchWrap())
        brightness = SeekBar(this).apply { max = 255; progress = brightnessValue }
        brightness.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { brightnessValue = progress }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) { sendState(JSONObject().put("bri", brightnessValue)); updateWidget() }
        })
        left.addView(brightness, LinearLayout.LayoutParams(-1, dp(30)))
        card.addView(left, LinearLayout.LayoutParams(0, dp(68), 1f))

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        actions.addView(roundAction("↗") { openWled() }, marginParams(0, 0, 0, 0, 4, 0))
        actions.addView(roundAction("⟳") { toggleSync() }, marginParams(0, 0, 0, 0, 4, 0))
        actions.addView(roundAction("⏻") { togglePower() })
        card.addView(actions, marginParams(-2, 0, 0, 0, 10, 0))
        root.addView(card, marginParams(-1, -2, 0, 0, 0, 4))
        root.addView(text("Смахивай по названию эффекта влево или вправо", 12f, 0xFF888888.toInt()), marginParams(-2, 12, 0, 0))
        root.addView(text("Для виджета: удерживай главный экран → Виджеты → WLED Nothing", 12f, 0xFF777777.toInt()), marginParams(-2, 20, 0, 0))
        setContentView(root)
        presetName.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { touchStartX = event.x; touchStartY = event.y; true }
                MotionEvent.ACTION_UP -> {
                    val dx = event.x - touchStartX
                    val dy = event.y - touchStartY
                    if (abs(dx) > dp(35) && abs(dx) > abs(dy)) {
                        movePreset(if (dx < 0) 1 else -1)
                    }
                    true
                }
                else -> true
            }
        }
        renderDots()
    }

    private fun saveHostAndConnect() {
        val value = hostInput.text.toString().trim().removePrefix("http://").removePrefix("https://").trimEnd('/')
        if (value.isBlank()) { status.text = "Введи IP-адрес контроллера"; return }
        prefs.edit().putString("host", value).apply()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(hostInput.windowToken, 0)
        refreshFromDevice()
    }

    private fun refreshFromDevice() {
        if (host.isBlank()) { updateWidget(); return }
        status.text = "Подключение…"
        thread {
            try {
                val state = WledApi.state(host)
                val list = try { WledApi.presets(host) } catch (_: Exception) { emptyList() }
                runOnUiThread {
                    presets = list
                    prefs.edit().putString("presetsJson", org.json.JSONArray().apply { list.forEach { put(org.json.JSONObject().put("id", it.id).put("name", it.name)) } }.toString()).apply()
                    isOn = state.optBoolean("on", true)
                    brightnessValue = state.optInt("bri", 190)
                    currentPresetId = state.optInt("ps", 0)
                    currentIndex = presets.indexOfFirst { it.id == currentPresetId }.let { if (it >= 0) it else 0 }
                    val udp = state.optJSONObject("udpn")
                    isSync = udp?.optBoolean("send", false) == true || udp?.optBoolean("recv", false) == true
                    brightness.progress = brightnessValue
                    brightness.isEnabled = isOn
                    presetName.text = presets.getOrNull(currentIndex)?.name ?: "WLED connected"
                    status.text = "Подключено · $host · ${presets.size} пресетов"
                    renderDots()
                    setGlowFromState(state)
                    updateWidget()
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Не удалось подключиться. Проверь IP и Wi‑Fi." }
            }
        }
    }

    private fun movePreset(delta: Int) {
        if (presets.isEmpty()) { status.text = "В WLED пока нет сохранённых пресетов"; return }
        currentIndex = (currentIndex + delta + presets.size) % presets.size
        val p = presets[currentIndex]
        currentPresetId = p.id
        presetName.text = p.name
        renderDots()
        sendState(JSONObject().put("ps", p.id).put("on", true))
        isOn = true
        brightness.isEnabled = true
        updateWidget()
    }

    private fun togglePower() {
        isOn = !isOn
        sendState(JSONObject().put("on", isOn))
        brightness.isEnabled = isOn
        updateWidget()
    }

    private fun toggleSync() {
        isSync = !isSync
        sendState(JSONObject().put("udpn", JSONObject().put("send", isSync).put("recv", isSync)))
        status.text = if (isSync) "Синхронизация UDP включена" else "Синхронизация UDP выключена"
        updateWidget()
    }

    private fun sendState(json: JSONObject) {
        if (host.isBlank()) { status.text = "Сначала укажи IP-адрес WLED"; return }
        thread {
            try {
                WledApi.send(host, json)
                val state = WledApi.state(host)
                runOnUiThread { setGlowFromState(state) }
            } catch (_: Exception) { runOnUiThread { status.text = "Ошибка отправки команды WLED" } }
        }
    }

    private fun openWled() {
        if (host.isBlank()) { status.text = "Сначала укажи IP-адрес WLED"; return }
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("http://$host")))
    }

    private fun setGlowFromState(state: JSONObject) {
        val segs = state.optJSONArray("seg")
        val seg = segs?.optJSONObject(0)
        val col = seg?.optJSONArray("col")?.optJSONArray(0)
        if (col != null && col.length() >= 3) {
            val r = col.optInt(0).coerceIn(0, 255)
            val g = col.optInt(1).coerceIn(0, 255)
            val b = col.optInt(2).coerceIn(0, 255)
            val glow = Color.rgb((r * .20).toInt(), (g * .20).toInt(), (b * .20).toInt())
            card.background = rounded(glow, 24)
            prefs.edit().putInt("glow", glow).apply()
        }
    }

    private fun renderDots() {
        if (!::dots.isInitialized) return
        dots.removeAllViews()
        val visible = presets.take(8)
        visible.forEachIndexed { index, p ->
            val dot = View(this).apply {
                background = rounded(if (index == currentIndex) Color.WHITE else 0x77FFFFFF, 8)
                contentDescription = p.name
                setOnClickListener { currentIndex = index; currentPresetId = p.id; presetName.text = p.name; renderDots(); sendState(JSONObject().put("ps", p.id).put("on", true)); isOn = true; updateWidget() }
            }
            val width = if (index == currentIndex) dp(12) else dp(6)
            dots.addView(dot, LinearLayout.LayoutParams(width, dp(5)).apply { marginStart = dp(2); marginEnd = dp(2) })
        }
    }

    private fun updateWidget() {
        val manager = AppWidgetManager.getInstance(this)
        val ids = manager.getAppWidgetIds(ComponentName(this, WledWidgetProvider::class.java))
        prefs.edit().putBoolean("on", isOn).putBoolean("sync", isSync).putInt("bri", brightnessValue)
            .putInt("presetId", currentPresetId).putString("presetName", presets.getOrNull(currentIndex)?.name ?: presetNameOrFallback())
            .putInt("presetCount", presets.size).putInt("presetIndex", currentIndex).apply()
        ids.forEach { WledWidgetProvider.update(this, manager, it) }
    }

    private fun presetNameOrFallback() = if (::presetName.isInitialized) presetName.text.toString() else "Rainbow"
    private fun roundAction(label: String, action: () -> Unit) = TextView(this).apply {
        text = label; textSize = if (label == "⏻") 21f else 20f; gravity = Gravity.CENTER
        setTextColor(if (label == "⏻" && isOn) 0xFF111111.toInt() else Color.WHITE)
        background = rounded(if (label == "⏻" && isOn) 0xFFEEEEEE.toInt() else 0xFF363636.toInt(), 50)
        setOnClickListener { action(); setTextColor(if (label == "⏻" && isOn) 0xFF111111.toInt() else Color.WHITE); background = rounded(if (label == "⏻" && isOn) 0xFFEEEEEE.toInt() else if (label == "⟳" && isSync) 0xFFEEEEEE.toInt() else 0xFF363636.toInt(), 50) }
    }.also { it.layoutParams = LinearLayout.LayoutParams(dp(38), dp(38)) }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 12f; isAllCaps = false; setTextColor(Color.WHITE)
        background = rounded(0xFF343434.toInt(), 14); setPadding(dp(12), 0, dp(12), 0)
        setOnClickListener { action() }
    }
    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun marginParams(w: Int, h: Int, l: Int, t: Int, r: Int = 0, b: Int = 0) = LinearLayout.LayoutParams(if (w == -2) ViewGroup.LayoutParams.WRAP_CONTENT else if (w == -1) ViewGroup.LayoutParams.MATCH_PARENT else dp(w), if (h == -2) ViewGroup.LayoutParams.WRAP_CONTENT else if (h == -1) ViewGroup.LayoutParams.MATCH_PARENT else dp(h)).apply { setMargins(dp(l), dp(t), dp(r), dp(b)) }
}
