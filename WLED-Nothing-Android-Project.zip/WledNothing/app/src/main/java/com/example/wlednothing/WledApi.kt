package com.example.wlednothing

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object WledApi {
    fun request(host: String, path: String, method: String = "GET", body: String? = null): String {
        val clean = host.trim().removePrefix("http://").removePrefix("https://").trimEnd('/')
        require(clean.isNotBlank()) { "Enter your WLED IP address" }
        val connection = (URL("http://$clean$path").openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 2500
            readTimeout = 2500
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
        }
        return try {
            if (body != null) connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            stream?.bufferedReader()?.use { it.readText() } ?: ""
        } finally { connection.disconnect() }
    }

    fun state(host: String): JSONObject = JSONObject(request(host, "/json/state"))
    fun send(host: String, json: JSONObject) { request(host, "/json/state", "POST", json.toString()) }

    fun presets(host: String): List<Preset> {
        val root = JSONObject(request(host, "/presets.json"))
        val result = mutableListOf<Preset>()
        val keys = root.keys().asSequence().toList().sortedBy { it.toIntOrNull() ?: Int.MAX_VALUE }
        for (key in keys) {
            val id = key.toIntOrNull() ?: continue
            if (id <= 0) continue
            val item = root.optJSONObject(key) ?: continue
            val name = item.optString("n", "").trim()
            if (name.isNotEmpty()) result += Preset(id, name)
        }
        return result
    }
}

data class Preset(val id: Int, val name: String)
